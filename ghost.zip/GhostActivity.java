package com.google.engedu.ghost;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;


public class GhostActivity extends AppCompatActivity {
    private static final String COMPUTER_TURN = "Computer's turn";
    private static final String USER_TURN = "Your turn";
    private GhostDictionary dictionary;
    private boolean userTurn = false;
    private Random random = new Random();

    private static final String TAG = "GhostActivity";

    static final String TEXT = "ghost_text";

    private FastDictionary word_dict;

    TextView gameStatus;
    TextView ghostText;
    TextView validWord;

    private Button challengeButton;

    private String wordFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ghost);


        // load xml

        validWord = (TextView)findViewById(R.id.wordStatus);

        challengeButton = (Button)findViewById(R.id.challengeButton);


        // Load the word dictionary
        try {
            word_dict = new FastDictionary(getAssets().open("words.txt"));
        } catch (Exception e){
            Log.d(TAG, "Exception thrown: " + e);
        }
        onStart(null);

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the user's current game state
        savedInstanceState.putString(TEXT, ghostText.getText().toString());

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    public void challengeButtonHandler(View view) {
        String new_word = word_dict.getGoodWordStartingWith(wordFragment);
        if(wordFragment.length() >= 4 && word_dict.isWord(wordFragment))  {
            gameStatus.setText("You have won.");
        }
        else if (new_word == null) {
                gameStatus.setText("You have won.");
        }
        else {
            Log.d(TAG, "computer has own because there is a word");
            gameStatus.setText("Computer has won.");
            ghostText.setText(new_word);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_ghost, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void computerTurn() {
        TextView label = (TextView) findViewById(R.id.gameStatus);

        // Do computer turn stuff then make it the user's turn again
        Log.d(TAG, "wordFragment = " + wordFragment);
        if(wordFragment.length() >= 4 && word_dict.isWord(wordFragment)) {
            Log.d(TAG, "computer has own because isword and length > 4");
            gameStatus.setText("Computer has won.");
            return;
        }
        if (word_dict.getGoodWordStartingWith(wordFragment) != null) {
            String new_word = word_dict.getGoodWordStartingWith(wordFragment);
            Log.d(TAG, "new_word = " + new_word);
            char new_char = new_word.charAt(wordFragment.length());
            wordFragment += new_char;
            ghostText.setText(wordFragment);
        }
        else {
            Log.d(TAG, "computer has own because WORD NOT FOUND");
            gameStatus.setText("Computer has won.");
            return ;
        }

        userTurn = true;
        gameStatus.setText(USER_TURN);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        wordFragment = ghostText.getText().toString().toLowerCase();
        char pressedKey = (char)event.getUnicodeChar();

        if (Character.isLetter(pressedKey)) {
            wordFragment += pressedKey;

            ghostText.setText(wordFragment);
            if (word_dict.isWord(wordFragment)) {
                validWord.setText("This is a valid word.");
            } else {
                validWord.setText("This is not valid word.");
            }
            gameStatus.setText("Computer's turn");
            computerTurn();
        }

        return super.onKeyUp(keyCode, event);
    }

    /**
     * Handler for the "Reset" button.
     * Randomly determines whether the game starts with a user turn or a computer turn.
     * @param view
     * @return true
     */
    public boolean onStart(View view) {
        userTurn = random.nextBoolean();
        wordFragment = "";

        gameStatus = (TextView)findViewById(R.id.gameStatus);
        ghostText = (TextView)findViewById(R.id.ghostText);

        ghostText.setText(wordFragment);

        if (userTurn) {
            gameStatus.setText(USER_TURN);
        } else {
            gameStatus.setText(COMPUTER_TURN);
            computerTurn();
        }
        return true;
    }


}

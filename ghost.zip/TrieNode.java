package com.google.engedu.ghost;

import android.util.Log;

import java.util.HashMap;
import java.util.Random;


public class TrieNode {
    private HashMap<String, TrieNode> children;
    private boolean isWord;

    private static final String TAG = "TrieNode";

    private Random rand = new Random();

    public TrieNode() {
        children = new HashMap<>();
        isWord = false;
    }

    public void add(String s) {
        // first we create the current node that is being called
        TrieNode currentNode = this;
        //find the word length to traverse
        int word_length = s.length();

        for (int level = 0; level < word_length; level++)
        {
            if ( !currentNode.children.containsKey(String.valueOf(s.charAt(level)))) {
                currentNode.children.put(String.valueOf(s.charAt(level)), new TrieNode());
            }
            currentNode = currentNode.children.get(String.valueOf(s.charAt(level)));
        }
        currentNode.isWord = true;
    }

    public boolean isWord(String s) {

        TrieNode currentNode = this;

        int word_length = s.length();

        for (int level = 0; level < word_length; level++) {
            if ( !currentNode.children.containsKey(String.valueOf(s.charAt(level)))) {
                return false;
            }
            currentNode = currentNode.children.get(String.valueOf(s.charAt(level)));
        }


        return currentNode.isWord;
    }

    public String getAnyWordStartingWith(String s) {

        TrieNode currentNode = this;

        int word_length = s.length();


        String newString = "";

        for (int level = 0; level < word_length; level++) {
            if ( !currentNode.children.containsKey(String.valueOf(s.charAt(level)))) {
                return null;
            }
            newString += s.charAt(level);
            currentNode = currentNode.children.get(String.valueOf(s.charAt(level)));
        }

        if ((currentNode.children.size()) == 0) {
            return null;
        }

        while (!currentNode.isWord) {

            for(char i = 'a'; i <= 'z'; i++) {
                if (currentNode.children.containsKey(String.valueOf(i))) {
                    newString += i;
                    currentNode = currentNode.children.get(String.valueOf(i));
                    break;
                }
            }
        }

        return newString;
    }

    public String getGoodWordStartingWith(String s) {
        Log.d(TAG, "dhukche");
        TrieNode currentNode = this;

        int word_length = s.length();

        String newString = "";

        for (int level = 0; level < word_length; level++) {
            if ( !currentNode.children.containsKey(String.valueOf(s.charAt(level)))) {
                return null;
            }
            newString += s.charAt(level);
            currentNode = currentNode.children.get(String.valueOf(s.charAt(level)));
        }

        Log.d(TAG, "newString = " + newString);
        Log.d(TAG, "cuurentNode.isWord = " + currentNode.isWord);
        if (currentNode.children.size() == 0) {
            return null;
        }
        while(!currentNode.isWord) {
            char c = (char)(rand.nextInt(26) + 'a');
            if(currentNode.children.containsKey(String.valueOf(c))) {
                newString += c;
                // (currentNode.children.get(String.valueOf(i+1))).isWord
                currentNode = currentNode.children.get(String.valueOf(c));
                Log.d(TAG, "newString = " + newString);
                Log.d(TAG, "isWord = " + currentNode.isWord);
                if((currentNode.isWord)) {
                    return newString;
                }
            }
        }
        return null;
    }



}
